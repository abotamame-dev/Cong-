<?php
// Deprecated: actions regroupées dans dashboard.php
header('Location: dashboard.php');
