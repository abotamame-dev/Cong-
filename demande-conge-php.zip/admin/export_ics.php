<?php
require_once __DIR__ . '/../db.php';
if (empty($_SESSION['admin'])) { header('HTTP/1.1 403 Forbidden'); exit; }

$pdo = db();
$employee = trim($_GET['emp'] ?? '');

$sql = 'SELECT * FROM requests WHERE status="approuvee"';
$params = [];
if ($employee !== '') { $sql .= ' AND full_name = ?'; $params[] = $employee; }
$sql .= ' ORDER BY start_date ASC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

header('Content-Type: text/calendar; charset=utf-8');
header('Content-Disposition: attachment; filename="conges_approuves.ics"');

echo "BEGIN:VCALENDAR\r\n";
echo "VERSION:2.0\r\n";
echo "PRODID:-//LeaveApp//FR//FR\r\n";
foreach ($rows as $r) {
    $uid = 'leave-'.$r['id'].'@leaveapp';
    $start = date('Ymd', strtotime($r['start_date']));
    $end = date('Ymd', strtotime($r['end_date'].' +1 day')); // all-day end is exclusive
    $summary = 'Congé - '.str_replace(['\r','\n'], ' ', $r['full_name']);
    $desc = 'Approuvé le '.($r['decided_at'] ? date('d/m/Y H:i', strtotime($r['decided_at'])) : '');
    echo "BEGIN:VEVENT\r\n";
    echo "UID:$uid\r\n";
    echo "DTSTAMP:".gmdate('Ymd\THis\Z')."\r\n";
    echo "DTSTART;VALUE=DATE:$start\r\n";
    echo "DTEND;VALUE=DATE:$end\r\n";
    echo "SUMMARY:".addcslashes($summary, ",;")."\r\n";
    echo "DESCRIPTION:".addcslashes($desc, ",;")."\r\n";
    echo "END:VEVENT\r\n";
}
echo "END:VCALENDAR\r\n";
