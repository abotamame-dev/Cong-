<?php
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../mailer.php';

if (empty($_SESSION['admin'])) { header('Location: login.php'); exit; }

$pdo = db();

// Filtre
$status = $_GET['status'] ?? 'toutes';
$valid_status = ['toutes','en_attente','approuvee','refusee'];
if (!in_array($status, $valid_status, true)) $status = 'toutes';

$query = 'SELECT * FROM requests';
$params = [];
if ($status !== 'toutes') {
    $query .= ' WHERE status = ?';
    $params[] = $status;
}
$query .= ' ORDER BY created_at DESC';
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Actions: approuver / refuser
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
        http_response_code(400); die('CSRF token invalide');
    }
    $id = (int)($_POST['id'] ?? 0);
    $act = $_POST['action'] ?? '';
    $r = $pdo->prepare('SELECT * FROM requests WHERE id = ?');
    $r->execute([$id]);
    $req = $r->fetch(PDO::FETCH_ASSOC);
    if ($req) {
        if ($act === 'approve' && $req['status'] !== 'approuvee') {
            $pdo->prepare('UPDATE requests SET status="approuvee", decided_at=? WHERE id=?')->execute([date('c'), $id]);
            // Email à l'employé
            $subject = "Demande de congé approuvée (#{$id})";
            $html = "<p>Bonjour ".htmlspecialchars($req['full_name']).",</p>
<p>Votre demande de congé pour la période <strong>".htmlspecialchars($req['start_date'])." → ".htmlspecialchars($req['end_date'])."</strong> a été <strong>approuvée</strong>.</p>
<p>Cordialement,<br>".SITE_NAME."</p>";
            send_mail($req['email'], $subject, $html);
            header('Location: dashboard.php?status='.$status.'&done=1'); exit;
        } elseif ($act === 'deny' && $req['status'] !== 'refusee') {
            $pdo->prepare('UPDATE requests SET status="refusee", decided_at=? WHERE id=?')->execute([date('c'), $id]);
            $subject = "Demande de congé refusée (#{$id})";
            $html = "<p>Bonjour ".htmlspecialchars($req['full_name']).",</p>
<p>Votre demande de congé pour la période <strong>".htmlspecialchars($req['start_date'])." → ".htmlspecialchars($req['end_date'])."</strong> a été <strong>refusée</strong>.</p>
<p>Cordialement,<br>".SITE_NAME."</p>";
            send_mail($req['email'], $subject, $html);
            header('Location: dashboard.php?status='.$status.'&done=1'); exit;
        }
    }
}

// Recharger liste après actions éventuelles
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin — Demandes</title>
  <link rel="stylesheet" href="../assets/styles.css">
</head>
<body>
  <main class="container">
    <header class="flex">
      <h1>Demandes de congé</h1>
      <nav>
        <a class="btn outline" href="?status=toutes">Toutes</a>
        <a class="btn outline" href="?status=en_attente">En attente</a>
        <a class="btn outline" href="?status=approuvee">Approuvées</a>
        <a class="btn outline" href="?status=refusee">Refusées</a>
        <a class="btn outline" href="calendar.php">Calendrier</a>
        <a class="btn" href="logout.php">Déconnexion</a>
      </nav>
    </header>

    <?php if (!empty($_GET['done'])): ?>
      <div class="alert success">Action effectuée et email envoyé.</div>
    <?php endif; ?>

    <div class="table">
      <div class="table-row header">
        <div>ID</div>
        <div>Employé</div>
        <div>Période</div>
        <div>Motif</div>
        <div>Statut</div>
        <div>Créée</div>
        <div>Action</div>
      </div>
      <?php foreach ($rows as $r): ?>
      <div class="table-row">
        <div>#<?php echo (int)$r['id']; ?></div>
        <div><?php echo htmlspecialchars($r['full_name']); ?><br><small><?php echo htmlspecialchars($r['email']); ?></small></div>
        <div><?php echo htmlspecialchars($r['start_date']); ?> → <?php echo htmlspecialchars($r['end_date']); ?></div>
        <div class="reason"><?php echo nl2br(htmlspecialchars($r['reason'] ?? '')); ?></div>
        <div>
          <?php
            $labels = ['en_attente'=>'En attente','approuvee'=>'Approuvée','refusee'=>'Refusée'];
            echo $labels[$r['status']] ?? htmlspecialchars($r['status']);
          ?>
        </div>
        <div><small><?php echo htmlspecialchars(date('d/m/Y H:i', strtotime($r['created_at']))); ?></small></div>
        <div>
          <form method="post" class="inline">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
            <input type="hidden" name="id" value="<?php echo (int)$r['id']; ?>">
            <button name="action" value="approve" <?php if ($r['status']==='approuvee') echo 'disabled'; ?>>Approuver</button>
            <button name="action" value="deny" class="danger" <?php if ($r['status']==='refusee') echo 'disabled'; ?>>Refuser</button>
          </form>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </main>
</body>
</html>
