<?php
require_once __DIR__ . '/../db.php';
if (empty($_SESSION['admin'])) { header('Location: login.php'); exit; }

$pdo = db();

// Params: month/year & employee filter
$year = isset($_GET['y']) ? (int)$_GET['y'] : (int)date('Y');
$month = isset($_GET['m']) ? (int)$_GET['m'] : (int)date('n');
if ($month < 1 || $month > 12) { $month = (int)date('n'); }
if ($year < 1970 || $year > 2100) { $year = (int)date('Y'); }
$employee = trim($_GET['emp'] ?? '');

// Get approved requests overlapping the month
$startMonth = sprintf('%04d-%02d-01', $year, $month);
$endMonth = date('Y-m-d', strtotime("$startMonth +1 month"));

// Build query
$sql = 'SELECT * FROM requests WHERE status="approuvee" AND NOT (end_date < ? OR start_date >= ?)';
$params = [$startMonth, $endMonth];
if ($employee !== '') {
    $sql .= ' AND full_name = ?';
    $params[] = $employee;
}
$sql .= ' ORDER BY start_date ASC';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$approved = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Distinct employee list for filter
$emps = $pdo->query('SELECT DISTINCT full_name FROM requests WHERE status="approuvee" ORDER BY full_name')->fetchAll(PDO::FETCH_COLUMN);

// Helper: color by name (HSL via hash)
function color_for($name) {
    $h = abs(crc32($name)) % 360;
    return "hsl($h, 70%, 85%)";
}

// Days grid (Mon -> Sun)
$firstDow = (int)date('N', strtotime($startMonth)); // 1 (Mon) .. 7 (Sun)
$daysInMonth = (int)date('t', strtotime($startMonth));

// Previous/Next month links
$prevMonthTs = strtotime("$startMonth -1 month");
$nextMonthTs = strtotime("$startMonth +1 month");
$prevY = (int)date('Y', $prevMonthTs);
$prevM = (int)date('n', $prevMonthTs);
$nextY = (int)date('Y', $nextMonthTs);
$nextM = (int)date('n', $nextMonthTs);

// Map of day -> events
$perDay = [];
for ($d=1; $d <= $daysInMonth; $d++) { $perDay[$d] = []; }

foreach ($approved as $r) {
    $s = strtotime($r['start_date']);
    $e = strtotime($r['end_date']);
    // Iterate each day in month range overlapped
    for ($day = 1; $day <= $daysInMonth; $day++) {
        $dStr = sprintf('%04d-%02d-%02d', $year, $month, $day);
        $ts = strtotime($dStr);
        if ($ts >= strtotime($r['start_date']) && $ts <= strtotime($r['end_date'])) {
            $perDay[$day][] = $r;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin — Calendrier</title>
  <link rel="stylesheet" href="../assets/styles.css">
  <style>
    .cal-header { display:flex; gap:10px; align-items:center; justify-content:space-between; margin-bottom:12px; }
    .cal-nav a{ text-decoration:none; }
    .calendar { display:grid; grid-template-columns: repeat(7, 1fr); gap:8px; }
    .cal-day { background:#fff; border:1px solid #e7e7ef; border-radius:8px; padding:8px; min-height:90px; }
    .cal-day .date { font-weight:700; font-size:0.95rem; margin-bottom:6px; }
    .cal-day .badge { display:block; padding:4px 6px; border-radius:6px; font-size:12px; margin-bottom:4px; line-height:1.2; }
    .cal-dow { font-weight:700; color:#666; padding:4px 6px; }
    .legend { display:flex; flex-wrap:wrap; gap:6px; margin:10px 0 0; }
    .legend .item { display:flex; align-items:center; gap:6px; padding:4px 6px; border:1px solid #e7e7ef; border-radius:8px; background:#fff; }
    .legend .swatch { width:12px; height:12px; border-radius:3px; }
    .filters { display:flex; gap:10px; align-items:center; }
    .muted{ color:#666; }
  </style>
</head>
<body>
  <main class="container">
    <header class="flex">
      <h1>Calendrier des congés (approuvés)</h1>
      <nav>
        <a class="btn outline" href="dashboard.php">Tableau</a>
        <a class="btn" href="logout.php">Déconnexion</a>
      </nav>
    </header>

    <div class="card">
      <div class="cal-header">
        <div class="filters">
          <form method="get">
            <input type="hidden" name="y" value="<?php echo $year; ?>">
            <input type="hidden" name="m" value="<?php echo $month; ?>">
            <label for="emp">Demandeur :</label>
            <select name="emp" id="emp" onchange="this.form.submit()">
              <option value="">Tous</option>
              <?php foreach ($emps as $e): ?>
                <option value="<?php echo htmlspecialchars($e); ?>" <?php if ($employee===$e) echo 'selected'; ?>>
                  <?php echo htmlspecialchars($e); ?>
                </option>
              <?php endforeach; ?>
            </select>
            <noscript><button type="submit">Filtrer</button></noscript>
          </form>
          <a class="btn outline" href="export_ics.php<?php echo $employee!=='' ? ('?emp='.urlencode($employee)) : ''; ?>">Exporter en .ics</a>
        </div>
        <div class="cal-nav">
          <a class="btn outline" href="?y=<?php echo $prevY; ?>&m=<?php echo $prevM; ?><?php echo $employee!==''?'&emp='.urlencode($employee):''; ?>">← Mois précédent</a>
          <strong><?php echo strftime('%B %Y', strtotime($startMonth)); ?></strong>
          <a class="btn outline" href="?y=<?php echo $nextY; ?>&m=<?php echo $nextM; ?><?php echo $employee!==''?'&emp='.urlencode($employee):''; ?>">Mois suivant →</a>
        </div>
      </div>

      <div class="calendar">
        <?php
          // Days of week headers (Mon..Sun)
          $dows = ['Lun','Mar','Mer','Jeu','Ven','Sam','Dim'];
          foreach ($dows as $d) { echo '<div class="cal-dow">'.$d.'</div>'; }
          // Empty cells before first day
          for ($i=1; $i < $firstDow; $i++) { echo '<div></div>'; }
          // Days
          for ($d=1; $d <= $daysInMonth; $d++) {
              echo '<div class="cal-day">';
              echo '<div class="date">'.$d.'</div>';
              foreach ($perDay[$d] as $ev) {
                  $bg = color_for($ev['full_name']);
                  $label = htmlspecialchars($ev['full_name']);
                  echo '<span class="badge" style="background:'.$bg.'">'.$label.'</span>';
              }
              echo '</div>';
          }
        ?>
      </div>

      <div class="legend">
        <?php
          $names = $employee!=='' ? [$employee] : array_unique(array_map(function($r){return $r['full_name'];}, $approved));
          foreach ($names as $n) {
              if ($n==='') continue;
              $bg = color_for($n);
              echo '<div class="item"><span class="swatch" style="background:'.$bg.'"></span><span>'.htmlspecialchars($n).'</span></div>';
          }
          if (empty($names)) echo '<span class="muted">Aucun congé approuvé sur la période.</span>';
        ?>
      </div>
    </div>
  </main>
</body>
</html>
