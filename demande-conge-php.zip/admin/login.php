<?php
require_once __DIR__ . '/../config.php';

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';
    if ($login === ADMIN_LOGIN && password_verify($password, ADMIN_PASSWORD_HASH)) {
        $_SESSION['admin'] = true;
        // regen id de session
        session_regenerate_id(true);
        header('Location: dashboard.php'); exit;
    } else {
        $err = 'Identifiants invalides';
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin — Connexion</title>
  <link rel="stylesheet" href="../assets/styles.css">
</head>
<body>
  <main class="container small">
    <h1>Espace admin</h1>
    <?php if ($err): ?><div class="alert error"><?php echo htmlspecialchars($err); ?></div><?php endif; ?>
    <form method="post" class="card">
      <div class="row">
        <label>Identifiant</label>
        <input type="text" name="login" required autocomplete="username">
      </div>
      <div class="row">
        <label>Mot de passe</label>
        <input type="password" name="password" required autocomplete="current-password">
      </div>
      <div class="row">
        <button type="submit">Se connecter</button>
      </div>
    </form>
    <p class="muted"><a href="../index.php">← Retour au formulaire</a></p>
  </main>
</body>
</html>
